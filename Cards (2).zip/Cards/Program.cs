﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
/*
 * @ author Travis Fultze
 * 
 * Unit Test 1: Logic Check of win method: ***UPDATE:**PASSED***
 * NOTE: Seriously consider switch statement if time alots 
 * 
 * Unit Test 2: Number gen logic test: ***UPDATE:**PASSED***
 * 
 * Unit Test 3: I found a strange error. Not sure how to track it down.
 * The game prompts me to continue when I select No. 
 * Screenshots of it will be in project folder. 
 * 
 * Unit Test 4: I dunno yet...
 * 
 * Next objective: 
 ****** Obj1: Loop the entire thing  ***UPDATE**FINISHED***
 * Obj2: In corpetate scoring system ***NEXT**P3*** 
 * Obj3: GUI 
 * Obj4: Count for number of consecutive wins after game has been looped ***NEXT**P2***
 * Obj5: Set game final win and lose method
 * Obj6: Code clean up
 ****** Obj7: Loop for tie // ***UPDATE:**FINISHED*** 
 * Obj8: Come up with more unit test and test as arise and place any new objective in objectives
 */

namespace Cards
{
   class Program
    {
        static void Main(string[] args)
        {
            Console.Write("Would you like to play a Game?\n");
            //Console.Write("Wanna play cards? Starts at 100 bucks:\n");
            play0();
            Console.ReadLine(); // So program doesn't end so abruptly 
        }
        static void play0()
        {
            string choice;
            do
            {
                Console.WriteLine("Enter:  'Y' for Yes.\t 'N' for No\n");
                choice = Console.ReadLine();
            }
            while ((!(choice == "Y" || choice == "y")) && (!(choice == "N" || choice == "n")));
            //while ((!(choice == "H" || choice == "h")) && (!(choice == "L" || choice == "l")))
            if (choice == "Y" || choice == "y")
            {
                Console.WriteLine("Cool");
                rules();
            }
            else if (choice == "N" || choice == "n")
                Console.WriteLine("Bye!");
          
        }
        static void rules()
        {
            Console.Write("I'll pull a card. \nThe number is from 1 to 13.\nYou guess if the next card" +
            " is 'higher' or 'lower'.\nIf you win, you get double.\nIf it's the same number then we'll retry.\n ");
            play();
        }
        static void play()
        {
            int number1 = guessNum1(0); 
            Console.WriteLine("\nThe first number is: " + number1);
            Console.WriteLine("Now, you guess will the next number be 'higher' or 'lower'. ");
            string choice = userChoice(null);
            int number2 = guessNum2(0);
            Console.WriteLine("\nThe next number is " + number2);
            winOrNaw(number1, number2, choice);
            playAgain();
        }
        // 2 methods for generating random numbers 
        static int guessNum1(int numb)
        {
            Random rand = new Random();
            numb = rand.Next(2 , 12);  // first number can't be a 1 or 13 
            return numb;
        }
        static int guessNum2(int numb)
        {
            Random rand = new Random();
            numb = rand.Next(1 , 13); 
            return numb;
        }
        static string userChoice(string choice)
        {
            do
            {
                Console.WriteLine("Enter:  'H' for High.\t 'L' for Low\n");
                choice = Console.ReadLine();
            }
            while ((!(choice == "H" || choice == "h")) && (!(choice == "L" || choice == "l")));
            return choice;
        }
        static string winOrNaw(int number1, int number2, string choice)
        {
            int n1 = number1;
            int n2 = number2;
            String output;
            // maybe turn to switch statement
            if (n1 < n2 && (choice == "H" || choice == "h"))
                output = "You win.";
            else if (n1 > n2 && (choice == "H" || choice == "h"))
                output = "Haha, you lose!";
            else if (n1 > n2 && (choice == "L" || choice == "l"))
                output = "You win.";
            else if (n1 < n2 && (choice == "L" || choice == "l"))
                output = "Haha, you lose!";
            else
                output = null; //"Tied we gotta retry";
            if (n1 == n2)
            {
                Console.WriteLine("Tied we gotta retry"); 
                play();
            } 
            Console.WriteLine(output);
            return output;
        }
        static void playAgain()
        {
            Console.Write("Wanna continue?\n");
            string choice;
            do
            {
                Console.WriteLine("Enter:  'Y' for Yes.\t 'N' for No\n");
                choice = Console.ReadLine();
            }
            while ((!(choice == "Y" || choice == "y")) && (!(choice == "N" || choice == "n")));
            
            if (choice == "Y" || choice == "y")
            {
                Console.WriteLine("Cool");
                play();
            }
            else
                Console.WriteLine("Scaredy Cat!");
        }

    } // End of class
       
} // End of namespace

