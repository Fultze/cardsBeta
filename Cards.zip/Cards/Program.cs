﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
/*
 * @ author Travis Fultze
 * Unit Test 1: Logic Check of win method: Passed...kinda 
 * Unit Test 2: Number gen logic test: Failed
 * Unit Test 3: I dunno yet.
 * 
 * Next objective: 
 * Obj1: Loop the entire thing
 * Obj2: In corpetate scoring system 
 * Obj3: GUI
 * Obj4: Count for number of contious wins after game has been looped
 * Obj5: Set game final win and lose method (again ties in with loops)
 * Obj6: Code clean up
 * Obj7: Loop for tie
 * Obj8: Come up with more unit test and test as arise and place any new objective in objectives
 */

namespace Cards
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.Write("Wanna play cards? Starts at 100 bucks:\n");
            Console.WriteLine("Enter:  'Y' for Yes.\t 'N' for No\n");
            play0();
            Console.ReadLine();
        }
        static void play0()
        {
            //  Change to while loop and switch statement
            String ans0 = Console.ReadLine();

            if (ans0 == "Y" || ans0 == "y")
            {
                Console.WriteLine("Cool");
                rules();   
            }
            else if (ans0 == "N" || ans0 == "n")
                Console.WriteLine("Bye!");
            else
                Console.WriteLine("You don't listen. Now, restart the program! ");

        }
        static void rules()
        {
            Console.Write("I'll pull a card. \nThe number is from 1 to 13.\nYou guess if the next card" +
            " is 'high' or 'low'.\nIf you win, you get double.\nIf it's the same number then we'll retry.\n ");
            play();
        }
        static void play()
        {
            int number1 = guessNum(0);
            Console.WriteLine("\nLet's play The first number is: " + number1);
            Console.WriteLine("Now you guess is the next number 'high' or 'lower'. ");
            string choice = userChoice(null);
            int number2 = guessNum(0);
            Console.WriteLine("\nThe next number is " + number2);
            winOrNaw(number1, number2, choice);
        }
        static int guessNum(int numb)
        {
            Random rand = new Random();
            numb = rand.Next(13); 
            return numb;
            /* change parameters gens 0,1,and 13
             * 1 and 13 ok for second number but not first
             */
        }
        static string userChoice(string choice)
        {
            do
            {
                Console.WriteLine("Enter:  'H' for High.\t 'L' for Low\n");
                choice = Console.ReadLine();
            }
            while (!(choice == "H" || choice == "L") && (!(choice == "h" || choice == "l")));
            Console.WriteLine("You chose " + choice); // This can go but leave in for now. 
            return choice;
        }
        static string winOrNaw(int number1, int number2, string choice)
        {
            int n1 = number1;
            int n2 = number2;
            String output;
            // maybe turn to switch statement
            if (n1 < n2 && (choice == "H" || choice == "h"))
                output = "You win";
            else if (n1 > n2 && (choice == "H" || choice == "h"))
                output = "You lose";
            else if (n1 > n2 && (choice == "L" || choice == "l"))
                output = "You win";
            else if (n1 < n2 && (choice == "L" || choice == "l"))
                output = "You lose";
            else 
                output = "Tied we gotta retry! ";
           
            Console.WriteLine(output);
            return output;
        }

        }
       
    }

